package com.example.loginapp.Retrofit;

import android.util.Log;


import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;


public class RetrofitClient {
    private static Retrofit instance;

    public static Retrofit getInstance(String url) {
        //        SharedPreferences prefs = context.getSharedPreferences("ipAddress", Context.MODE_PRIVATE);
//        String baseUrl = prefs.getString("base_url", null);
        Log.i("blabla", "URL: " + url);
        if(instance == null)
            instance = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(ScalarsConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();


         return instance;
    }
}
