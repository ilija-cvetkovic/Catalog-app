package com.example.loginapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.example.loginapp.Retrofit.MyService;
import com.example.loginapp.Retrofit.RetrofitClient;
import com.github.javiersantos.materialstyleddialogs.MaterialStyledDialog;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.io.Console;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    TextView txt_create_account;
    MaterialEditText edt_login_email, edt_login_password;
    Button btn_login;
    int pom;
    private boolean isVisible = false;


    CompositeDisposable compositeDisposable = new CompositeDisposable();
    MyService myService;

    @Override
    protected void onStop() {
        compositeDisposable.clear();
        super.onStop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //init view
        edt_login_email = findViewById(R.id.edt_email);
        edt_login_password = findViewById(R.id.edt_password);

        final ConstraintLayout inputConstraint = findViewById(R.id.input_constraint);
        final EditText addAddress = findViewById(R.id.add_address_text);
        final Button addAddressBtn = findViewById(R.id.add_address_btn);
        btn_login = findViewById(R.id.btn_login);
        Button showIpInput = findViewById(R.id.show_ip_input);
        //init service

        //Dugme za prikaz inputa za adresu
        showIpInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isVisible){
                    inputConstraint.setVisibility(View.VISIBLE);
                    btn_login.setVisibility(View.VISIBLE);
                    addAddress.setVisibility(View.INVISIBLE);
                    addAddressBtn.setVisibility(View.INVISIBLE);
                    isVisible = false;
                }else {
                    addAddress.setVisibility(View.VISIBLE);
                    addAddressBtn.setVisibility(View.VISIBLE);
                    inputConstraint.setVisibility(View.INVISIBLE);
                    btn_login.setVisibility(View.INVISIBLE);
                    isVisible = true;
                }

            }
        });
        //Dugme za prosledjivanje adrese
        addAddressBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = addAddress.getText().toString();
                if(!url.isEmpty()){
                    if(url.contains("http://") && url.contains(":3000") && !url.contains("::")){
                        Retrofit retrofitClient = RetrofitClient.getInstance(url);
                        myService = retrofitClient.create(MyService.class);

                        Toast.makeText(MainActivity.this, "IP:" + url, Toast.LENGTH_SHORT).show();

                        //promena inputa kada je adresa validna
                        inputConstraint.setVisibility(View.VISIBLE);
                        btn_login.setVisibility(View.VISIBLE);
                        addAddress.setVisibility(View.INVISIBLE);
                        addAddressBtn.setVisibility(View.INVISIBLE);
                        isVisible = false;
                    }else {
                        Toast.makeText(MainActivity.this, "Morate uneti https:// i port za slusanje", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(MainActivity.this, "Unesite ip adresu", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    loginUser(edt_login_email.getText().toString(),
                            edt_login_password.getText().toString());


            }

        });

        txt_create_account = findViewById(R.id.txt_nalog);
        txt_create_account.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                 final View register_layout = LayoutInflater.from(MainActivity.this)
                         .inflate(R.layout.register_layout,null);


                 new MaterialStyledDialog.Builder(MainActivity.this)
                        .setTitle("REGISTRACIJA")
                        .setDescription("Molim vas popunite polja")
                        .setCustomView(register_layout)
                        .setNegativeText("IZLAZ")
                        .onNegative(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which)
                            {
                                dialog.dismiss();
                            }
                        })
                        .setPositiveText("POTVRDA")
                         .onPositive(new MaterialDialog.SingleButtonCallback()
                         {
                             @Override
                             public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {

                                 MaterialEditText edt_register_email = (MaterialEditText)register_layout.findViewById(R.id.edt_email);
                                 MaterialEditText edt_register_name = (MaterialEditText)register_layout.findViewById(R.id.edt_name);
                                 MaterialEditText edt_register_password = (MaterialEditText)register_layout.findViewById(R.id.edt_password);


                                 if(TextUtils.isEmpty(edt_register_email.getText().toString()))
                                 {
                                     Toast.makeText(MainActivity.this,"Email polje ne sme biti prazno",Toast.LENGTH_SHORT).show();
                                     return;
                                 }

                                 if(TextUtils.isEmpty(edt_register_name.getText().toString()))
                                 {
                                     Toast.makeText(MainActivity.this,"Username polje ne sme biti prazno",Toast.LENGTH_SHORT).show();
                                     return;
                                 }

                                 if(TextUtils.isEmpty(edt_register_password.getText().toString()))
                                 {
                                     Toast.makeText(MainActivity.this,"Password polje ne sme biti prazno",Toast.LENGTH_SHORT).show();
                                     return;
                                 }

                                 registerUser(edt_register_email.getText().toString(),
                                         edt_register_name.getText().toString(),
                                         edt_register_password.getText().toString());


                             }
                         }).show();


            }
        });
    }


    private void registerUser(String email, String name, String password)
    {
            compositeDisposable.add(myService.registerUser(email, name, password)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(new Consumer<String>() {
                      @Override
                      public void accept(String response) throws Exception {
                            Toast.makeText(MainActivity.this, "" + response, Toast.LENGTH_SHORT).show();

                      }
                    }));


    }
    private final String provera  =  "\"Uspesno ste se ulogovali\"" ;
    private void loginUser(String email, String password)
    {

        //final String provera  =  "Uspesno ste se ulogovali" ;

        if(TextUtils.isEmpty(email))
        {
            Toast.makeText(this,"Email polje ne sme biti prazno",Toast.LENGTH_SHORT).show();
            return;
        }

        if(TextUtils.isEmpty(password))
        {
            Toast.makeText(this,"Password polje ne sme biti prazno",Toast.LENGTH_SHORT).show();
            return;
        }


        compositeDisposable.add(myService.loginUser(email,password)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<String>(){
                    public void accept(String response) throws Exception
                    {

                        //Log.v("response", response);
                        //Log.v("provera", provera);

                        if(provera.compareTo(response) == 0)
                        {
                            Intent intent = new Intent(MainActivity.this,Meni.class);
                            startActivity(intent);

                        }
                        else
                        {
                            pom --;

                            if(pom == 0)
                            {
                                btn_login.setEnabled(false);
                            }
                        }

                        Toast.makeText(MainActivity.this,"" +response,Toast.LENGTH_SHORT).show();

                    }


                })




        );
    }
}
