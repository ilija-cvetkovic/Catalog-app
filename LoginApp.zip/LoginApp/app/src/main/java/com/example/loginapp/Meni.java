package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Meni extends AppCompatActivity {
    private Button procesor;
    private Button mat_ploca;
    private Button graficka;
    private Button hdd;
    private Button ram;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meni);

        procesor = (Button) findViewById(R.id.btn_procesor);
        procesor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openProcesor();
            }
        });

        mat_ploca = (Button) findViewById(R.id.btn_mat_ploca);
        mat_ploca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMaticna();
            }
        });

        graficka = (Button) findViewById(R.id.btn_graficka);
        graficka.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGraficka();
            }
        });

        ram = (Button) findViewById(R.id.btn_ram);
        ram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRam();
            }
        });

        hdd = (Button) findViewById(R.id.btn_hdd);
        hdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHDD();
            }
        });

    }

    public void openGraficka() {
        Intent intent = new Intent(this,Graficka.class);
        startActivity(intent);
    }

    public void openMaticna() {
        Intent intent = new Intent(this,Maticna.class);
        startActivity(intent);
    }

    public void openProcesor() {
        Intent intent = new Intent(this, Procesor.class);
        startActivity(intent);
    }

    public void openRam() {
        Intent intent = new Intent(this, ram.class);
        startActivity(intent);
    }
    public void openHDD() {
        Intent intent = new Intent(this, HDD.class);
        startActivity(intent);
    }
}
