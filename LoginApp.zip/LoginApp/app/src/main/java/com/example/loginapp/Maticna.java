package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Maticna extends AppCompatActivity {
    private Button x470;
    private Button x570;
    private Button b360;
    private Button b365;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maticna);


        x470 = (Button) findViewById(R.id.btn_x470);
        x470.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openX470();
            }
        });


        x570 = (Button) findViewById(R.id.btn_x570);
        x570.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openX570();
            }
        });

        b360 = (Button) findViewById(R.id.btn_b360);
        b360.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openB360();
            }
        });

        b365 = (Button) findViewById(R.id.btn_b365);
        b365.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openB365();
            }
        });


    }

    private void openX470() {
        Intent intent = new Intent(this,x470.class);
        startActivity(intent);
    }

    private void openX570() {
        Intent intent = new Intent(this,x570.class);
        startActivity(intent);
    }

    private void openB360() {
        Intent intent = new Intent(this,b360.class);
        startActivity(intent);
    }

    private void openB365() {
        Intent intent = new Intent(this,b365.class);
        startActivity(intent);
    }
}
