package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HDD extends AppCompatActivity {
    private Button hdd1;
    private Button hdd2;
    private Button ssd1;
    private Button ssd2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hdd);


        hdd1 = (Button) findViewById(R.id.btn_hdd1);
        hdd1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHDD1();
            }
        });


        hdd2 = (Button) findViewById(R.id.btn_hdd2);
        hdd2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHDD2();
            }
        });

        ssd1 = (Button) findViewById(R.id.btn_ssd1);
        ssd1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSSD1();
            }
        });

        ssd2 = (Button) findViewById(R.id.btn_ssd2);
        ssd2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSSD2();
            }
        });


    }

    private void openHDD1() {
        Intent intent = new Intent(this,hdd1.class);
        startActivity(intent);
    }

    private void openHDD2() {
        Intent intent = new Intent(this,hdd2.class);
        startActivity(intent);
    }

    private void openSSD1() {
        Intent intent = new Intent(this,ssd1.class);
        startActivity(intent);
    }

    private void openSSD2() {
        Intent intent = new Intent(this,ssd2.class);
        startActivity(intent);
    }
}
