package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class radeon extends AppCompatActivity {
    private Button rx580;
    private Button rx590;
    private Button rx5700;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radeon);


        rx580 = (Button) findViewById(R.id.btn_rx580);
        rx580.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRx580();
            }
        });


        rx590 = (Button) findViewById(R.id.btn_rx590);
        rx590.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRx590();
            }
        });

        rx5700 = (Button) findViewById(R.id.btn_rx5700);
        rx5700.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRx5700();
            }
        });



    }

    private void openRx580() {
        Intent intent = new Intent(this,rx580.class);
        startActivity(intent);
    }

    private void openRx590() {
        Intent intent = new Intent(this,rx590.class);
        startActivity(intent);
    }

    private void openRx5700() {
        Intent intent = new Intent(this,rx5700.class);
        startActivity(intent);
    }

}
