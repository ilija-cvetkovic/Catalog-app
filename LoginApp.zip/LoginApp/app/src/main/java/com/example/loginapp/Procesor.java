package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Procesor extends AppCompatActivity {
    private Button intel;
    private Button amd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_procesor);

        intel = (Button) findViewById(R.id.btn_intel);
        intel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openIntel();
            }
        });

        amd = (Button) findViewById(R.id.btn_amd);
        amd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAMD();
            }
        });
    }

    private void openAMD() {
        Intent intent = new Intent(this,AMD.class);
        startActivity(intent);
    }

    private void openIntel() {
        Intent intent = new Intent(this,Intel.class);
        startActivity(intent);
    }
}
