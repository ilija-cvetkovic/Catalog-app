package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Graficka extends AppCompatActivity {
    private Button nvidia;
    private Button radeon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graficka);

        nvidia = (Button) findViewById(R.id.btn_nvidia);
        nvidia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNvidia();
            }
        });

        radeon = (Button) findViewById(R.id.btn_radeon);
        radeon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRadeon();
            }
        });
    }

    private void openRadeon() {
        Intent intent = new Intent(this,radeon.class);
        startActivity(intent);
    }

    private void openNvidia() {
        Intent intent = new Intent(this,nvidia.class);
        startActivity(intent);
    }
}
