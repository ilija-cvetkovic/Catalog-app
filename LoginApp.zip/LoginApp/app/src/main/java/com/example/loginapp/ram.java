package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ram extends AppCompatActivity {
    private Button gb8;
    private Button gb16;
    private Button gb2x16;
    private Button gb4x8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ram);


        gb8 = (Button) findViewById(R.id.btn_gb8);
        gb8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGb8();
            }
        });


        gb16 = (Button) findViewById(R.id.btn_gb16);
        gb16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGb16();
            }
        });

        gb2x16 = (Button) findViewById(R.id.btn_gb2x16);
        gb2x16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGb2x16();
            }
        });

        gb4x8 = (Button) findViewById(R.id.btn_gb4x8);
        gb4x8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGb4x8();
            }
        });


    }

    private void openGb8() {
        Intent intent = new Intent(this,gb8.class);
        startActivity(intent);
    }

    private void openGb16() {
        Intent intent = new Intent(this,gb16.class);
        startActivity(intent);
    }

    private void openGb2x16() {
        Intent intent = new Intent(this,gb2x16.class);
        startActivity(intent);
    }

    private void openGb4x8() {
        Intent intent = new Intent(this,gb4x8.class);
        startActivity(intent);
    }
}
