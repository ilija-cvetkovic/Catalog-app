package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class nvidia extends AppCompatActivity {
    private Button gtx1080;
    private Button gtx2070;
    private Button gtx2080;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nvidia);


        gtx1080 = (Button) findViewById(R.id.btn_gtx1080);
        gtx1080.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGtx1080();
            }
        });


        gtx2070 = (Button) findViewById(R.id.btn_gtx2070);
        gtx2070.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGtx2070();
            }
        });

        gtx2080 = (Button) findViewById(R.id.btn_gtx2080);
        gtx2080.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGtx2080();
            }
        });



    }

    private void openGtx1080() {
        Intent intent = new Intent(this,gtx1080.class);
        startActivity(intent);
    }

    private void openGtx2070() {
        Intent intent = new Intent(this,gtx2070.class);
        startActivity(intent);
    }

    private void openGtx2080() {
        Intent intent = new Intent(this,gtx2080.class);
        startActivity(intent);
    }


}
