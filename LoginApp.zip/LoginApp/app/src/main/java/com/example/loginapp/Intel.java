package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Intel extends AppCompatActivity {
    private Button inteli3;
    private Button inteli5;
    private Button inteli7;
    private Button inteli9;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intel);


        inteli3 = (Button) findViewById(R.id.btn_inteli3);
        inteli3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openInteli3();
            }
        });


        inteli5 = (Button) findViewById(R.id.btn_inteli5);
        inteli5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openInteli5();
            }
        });

        inteli7 = (Button) findViewById(R.id.btn_inteli7);
        inteli7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openInteli7();
            }
        });

        inteli9 = (Button) findViewById(R.id.btn_inteli9);
        inteli9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openInteli9();
            }
        });


    }

    private void openInteli3() {
        Intent intent = new Intent(this,inteli3.class);
        startActivity(intent);
    }

    private void openInteli5() {
        Intent intent = new Intent(this,inteli5.class);
        startActivity(intent);
    }

    private void openInteli7() {
        Intent intent = new Intent(this,inteli7.class);
        startActivity(intent);
    }

    private void openInteli9() {
        Intent intent = new Intent(this,inteli9.class);
        startActivity(intent);
    }
}
