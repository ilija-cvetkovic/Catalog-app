package com.example.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AMD extends AppCompatActivity {
    private Button ryzen3;
    private Button ryzen5;
    private Button ryzen7;
    private Button ryzen9;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amd);


        ryzen3 = (Button) findViewById(R.id.btn_ryzen3);
        ryzen3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRyzen3();
            }
        });


        ryzen5 = (Button) findViewById(R.id.btn_ryzen5);
        ryzen5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRyzen5();
            }
        });

        ryzen7 = (Button) findViewById(R.id.btn_ryzen7);
        ryzen7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRyzen7();
            }
        });

        ryzen9 = (Button) findViewById(R.id.btn_ryzen9);
        ryzen9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRyzen9();
            }
        });


    }

    private void openRyzen9() {
        Intent intent = new Intent(this,ryzen9.class);
        startActivity(intent);
    }

    private void openRyzen7() {
        Intent intent = new Intent(this,Ryzen7.class);
        startActivity(intent);
    }

    private void openRyzen5() {
        Intent intent = new Intent(this,Ryzen5.class);
        startActivity(intent);
    }

    private void openRyzen3() {
        Intent intent = new Intent(this,Ryzen3.class);
        startActivity(intent);
    }
}
